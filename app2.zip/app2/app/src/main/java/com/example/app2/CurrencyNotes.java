package com.example.app2;

import java.util.Scanner;

public class CurrencyNotes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the amount to be withdrawn in hundreds
        System.out.print("Enter the amount to be withdrawn in hundreds: ");
        int amountInHundreds = scanner.nextInt();

        // Calculate the number of notes of each denomination
        int hundreds = amountInHundreds;
        int fifties = 0;
        int tens = 0;
        int ones = 0;

        if (hundreds >= 5) {
            fifties = hundreds / 5;
            hundreds -= fifties * 5;
        }

        if (hundreds >= 2) {
            tens = hundreds / 2;
            hundreds -= tens * 2;
        }

        ones = hundreds;

        // Display the result
        System.out.println("Number of 100 notes: " + (amountInHundreds - fifties - tens - ones));
        System.out.println("Number of 50 notes: " + fifties);
        System.out.println("Number of 10 notes: " + (tens * 10));
        System.out.println("Number of 1 notes: " + ones);
    }
}
