package com.example.app2;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    EditText firstNumberEditText, secondNumberEditText;
    Button addButton, multiplyButton, subtractButton, divideButton, modulusButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        firstNumberEditText = findViewById(R.id.editText1);
        secondNumberEditText = findViewById(R.id.editText2);
        addButton = findViewById(R.id.button1);
        multiplyButton = findViewById(R.id.button2);
        subtractButton = findViewById(R.id.button3);
        divideButton = findViewById(R.id.button4);
        modulusButton = findViewById(R.id.button5);
        resultTextView = findViewById(R.id.resultTextView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(firstNumberEditText.getText().toString()) +
                        Double.parseDouble(secondNumberEditText.getText().toString());
                resultTextView.setText(String.format("%.2f", result));
            }
        });

        multiplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(firstNumberEditText.getText().toString()) *
                        Double.parseDouble(secondNumberEditText.getText().toString());
                resultTextView.setText(String.format("%.2f", result));
            }
        });

        subtractButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(firstNumberEditText.getText().toString()) -
                        Double.parseDouble(secondNumberEditText.getText().toString());
                resultTextView.setText(String.format("%.2f", result));
            }
        });

        divideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(firstNumberEditText.getText().toString()) /
                        Double.parseDouble(secondNumberEditText.getText().toString());
                resultTextView.setText(String.format("%.2f", result));
            }
        });

        modulusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(firstNumberEditText.getText().toString()) %
                        Double.parseDouble(secondNumberEditText.getText().toString());
                resultTextView.setText(String.format("%.2f", result));
            }
        });
    }
}
